import React, { useState } from 'react';
import { useNavigate } from "react-router-dom";
import { TextField, Button, Box, Alert } from '@mui/material';
import { NavLink } from 'react-router-dom';

const UserLogin = () => {
    let navigate = useNavigate();
    const [error, setError] = useState({
        status: false,
        msg: '',
        type: ''
    })

    const handleSubmit = (e) => {
        e.preventDefault();
        const data = new FormData(e.currentTarget);
        const actualData = {
            email: data.get('email'),
            password: data.get('password')
        }
        if (actualData.email && actualData.password) {
            console.log('actualData>>', actualData);
            document.getElementById('login-form').reset()
            setError({
                status: true, msg: 'Login Success',
                type: 'success'
            })
            navigate('/deshboard');
        } else {
            setError({
                status: true, msg: 'All Fields are Required',
                type: 'error'
            })
        }
    }
    return (
        <>
            <Box component='form' noValidate sx={{ mt: 2, p: 3 }} id='login-form' onSubmit={handleSubmit}>
                <TextField margin='normal' required fullWidth id='email' name='email' label='Email Address' />
                <TextField margin='normal' required fullWidth id='password'
                    name='password' label='Password' type='password' />
                {
                    error.status ? <Alert severity={error.type}>{error.msg}</Alert> : ''
                }
                <Box textAlign='center'>
                    <Button type='submit' variant='contained'
                        sx={{ textTransform: 'none', mt: 3, mb: 2, px: 5 }}>Login</Button>
                </Box>
                <NavLink to='/sendPasswordResetEmail'>Forgot Password ?</NavLink><br></br>
                <NavLink to='/changePassword'>Change Password ?</NavLink>
            </Box>
        </>
    )
}
export default UserLogin;