import React from 'react';

const Contact = () => {
    return (
        <div className='p-3'>
            <h2>Contact Page</h2>
            <hr />
            <p>
                Contact Lorem, ipsum dolor sit amet consectetur adipisicing elit. Consectetur modi voluptas ducimus similique,
                voluptatum neque mollitia? Quaerat vero earum suscipit est itaque blanditiis rem cum deleniti, esse animi
                veniam corrupti temporibus provident ducimus in similique? Ea laudantium aut corrupti itaque maxime
                provident, voluptas id aperiam sit qui nihil exercitationem voluptatum quisquam eum impedit commodi
                atque ipsa, magnam rerum aliquid sequi saepe blanditiis autem tenetur. Labore consequatur unde quo ea
                illum laborum odio, dicta cumque assumenda molestiae omnis asperiores ex perspiciatis vel, animi
                iusto reprehenderit optio eveniet reiciendis voluptates. Tempore voluptate dolores blanditiis in
                ipsam reprehenderit? Omnis repellat voluptas fuga doloribus.
            </p>
        </div>
    )
}
export default Contact;